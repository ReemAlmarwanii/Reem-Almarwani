#!/usr/bin/env python3
"""
ibd_npm_pipeline_from_scratch.py

From-scratch npm-only pipeline for the paper:
"Adversary-Aware Explainable Detection of Malicious npm Packages via
Intent–Behavior Discordance"

What this script does
---------------------
1) Build malicious manifests from public malicious-package sources
   (DataDog + OpenSSF), restricted to npm.
2) Build a benign npm manifest from the npm search API.
3) Build an npm-only live corpus by enriching manifests from the npm registry
   and optionally scanning package tarballs.
4) Build metadata, behavior-proxy, and discordance features.
5) Run the six paper-aligned analyses:
   - clean in-domain evaluation
   - availability-matched evaluation
   - deception attacks
   - temporal split evaluation
   - metadata feature-group ablation
   - ranking-based triage evaluation
6) Save all artifacts (CSV / JSON) needed for manuscript tables.

Important methodological note
-----------------------------
This script is designed to reproduce the *workflow* and evaluation logic of the
paper from scratch. It does not guarantee exact replication of previously reported
numbers because those depended on a specific archived processed corpus and split-
specific outputs. When live registry data changes, exact counts and scores may shift.

Requirements
------------
Python 3.10+
pip install pandas numpy requests scikit-learn

Optional for cloning malicious-package source repos:
- git

Typical usage
-------------
# Full end-to-end npm workflow
python ibd_npm_pipeline_from_scratch.py full_npm \
  --base-dir /path/to/project \
  --work-dir /path/to/external_sources \
  --clone-if-missing \
  --malicious-target 2500 \
  --benign-target 2500 \
  --tarball-max-files 250 \
  --tarball-max-bytes 2500000

Outputs
-------
base-dir/
  manifests/
  manifests_npm/
  data_npm_live/
  features_npm_live/
  experiments_npm_clean_matched/
  experiments_npm_attacks/
  temporal_eval/
  metadata_ablation/
  ranking_triage_eval/
  manifests/artifact_manifest.json
"""

from __future__ import annotations

import argparse
import io
import json
import math
import os
import random
import re
import subprocess
import sys
import tarfile
import time
from collections import defaultdict
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    brier_score_loss,
    f1_score,
    log_loss,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.base import clone
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler


# ============================================================
# Configuration
# ============================================================

USER_AGENT = "ibd-npm-from-scratch/1.0"
DATADOG_REPO_URL = "https://github.com/DataDog/malicious-software-packages-dataset.git"
OSSF_REPO_URL = "https://github.com/ossf/malicious-packages.git"

NPM_SEARCH_TERMS = [
    "utility", "helpers", "react", "vue", "cli", "build", "test", "lint",
    "format", "markdown", "string", "date", "http", "api", "server",
    "client", "file", "path", "crypto", "parser", "json", "yaml", "xml",
    "logger", "config", "cache", "stream", "image", "css", "typescript"
]

DEFAULT_TEXT_COLUMNS = [
    "package_name",
    "summary",
    "description",
    "readme",
    "keywords",
    "homepage",
    "project_urls",
    "repository_url",
    "author",
    "maintainers",
    "license",
    "requires_dist",
    "scripts_text",
    "dist_urls",
]

# Five coarse role categories as described in the manuscript.
ROLE_KEYWORDS: Dict[str, List[str]] = {
    "documentation_formatting": [
        "doc", "docs", "documentation", "markdown", "format", "formatter",
        "prettier", "lint", "style", "syntax", "render", "rst"
    ],
    "build_tooling": [
        "build", "cli", "tool", "devtool", "plugin", "webpack", "babel",
        "rollup", "vite", "compiler", "transpile", "test", "ci"
    ],
    "package_archive_utility": [
        "archive", "zip", "tar", "compress", "extract", "pack", "unpack",
        "file", "filesystem", "fs", "path"
    ],
    "deployment_automation": [
        "deploy", "automation", "infra", "docker", "kubernetes", "ansible",
        "release", "pipeline", "workflow", "provision", "server", "cloud"
    ],
    "data_network_service": [
        "http", "network", "api", "client", "server", "request", "data",
        "scrape", "socket", "download", "upload", "service"
    ],
}

ROLE_ALLOWANCES: Dict[str, Dict[str, float]] = {
    "documentation_formatting": {
        "installation_hook": 0.10, "shell_exec": 0.05, "network_access": 0.15,
        "environment_access": 0.10, "credential_access": 0.00, "obfuscation": 0.00,
        "downloader": 0.00, "suspicious_hits": 0.10,
    },
    "build_tooling": {
        "installation_hook": 0.75, "shell_exec": 0.70, "network_access": 0.40,
        "environment_access": 0.40, "credential_access": 0.10, "obfuscation": 0.05,
        "downloader": 0.15, "suspicious_hits": 0.50,
    },
    "package_archive_utility": {
        "installation_hook": 0.25, "shell_exec": 0.20, "network_access": 0.15,
        "environment_access": 0.20, "credential_access": 0.05, "obfuscation": 0.05,
        "downloader": 0.05, "suspicious_hits": 0.25,
    },
    "deployment_automation": {
        "installation_hook": 0.70, "shell_exec": 0.85, "network_access": 0.75,
        "environment_access": 0.50, "credential_access": 0.30, "obfuscation": 0.05,
        "downloader": 0.35, "suspicious_hits": 0.60,
    },
    "data_network_service": {
        "installation_hook": 0.20, "shell_exec": 0.15, "network_access": 0.85,
        "environment_access": 0.35, "credential_access": 0.15, "obfuscation": 0.05,
        "downloader": 0.25, "suspicious_hits": 0.45,
    },
}

DISCORDANCE_WEIGHTS = {
    "installation_hook": 1.0,
    "shell_exec": 1.2,
    "network_access": 1.0,
    "environment_access": 0.9,
    "credential_access": 1.5,
    "obfuscation": 1.4,
    "downloader": 1.2,
    "suspicious_hits": 0.8,
}

ROLE_SPOOF_SNIPPETS = {
    "docs": {
        "summary": "Documentation and formatting helper for clean text workflows.",
        "description": "A lightweight documentation formatting utility for rendering and style normalization.",
        "keywords": "docs,markdown,format,formatter,render,style",
        "readme_prefix": "# Documentation helper\nThis package provides lightweight formatting helpers for markdown and docs.\n",
    },
    "utility": {
        "summary": "Small utility package for common data and string helper tasks.",
        "description": "A general-purpose helper package for common utility operations.",
        "keywords": "utility,helpers,tools,common,data",
        "readme_prefix": "# Utility package\nThis package contains simple helpers for common development tasks.\n",
    },
    "network": {
        "summary": "HTTP and API helper toolkit for client-side service access.",
        "description": "A small toolkit for API requests and service integration workflows.",
        "keywords": "http,api,client,service,requests,network",
        "readme_prefix": "# API helper\nThis package provides lightweight request and integration helpers.\n",
    },
}

BASIC_BLANK_FIELDS = [
    "summary",
    "description",
    "keywords",
    "homepage",
    "project_urls",
    "repository_url",
]

RISK_PATTERNS: Dict[str, List[str]] = {
    "installation_hook": [
        r"\bpreinstall\b",
        r"\bpostinstall\b",
        r"\binstall\b",
        r"\bsetup\.py\b",
        r"\bentry_points\b",
    ],
    "shell_exec": [
        r"\bchild_process\b", r"\bexec\b", r"\bspawn\b", r"\bos\.system\b",
        r"\bsubprocess\b", r"\bpopen\b", r"\bShellExecute\b", r"\bcmd\.exe\b",
        r"\bpowershell\b", r"\bbash\b", r"\bsh\b",
    ],
    "network_access": [
        r"\bhttps?://", r"\bfetch\b", r"\baxios\b", r"\brequest(s)?\b",
        r"\burllib\b", r"\bhttpx\b", r"\bsocket\b", r"\bnet\.connect\b",
        r"\bXMLHttpRequest\b",
    ],
    "environment_access": [
        r"\bprocess\.env\b", r"\bos\.environ\b", r"\bgetenv\b", r"\benviron\b",
        r"\bHOME\b", r"\bUSERPROFILE\b", r"\bAPPDATA\b",
    ],
    "credential_access": [
        r"\btoken\b", r"\bcredential\b", r"\bpassword\b", r"\bsecret\b",
        r"\bauth\b", r"\bssh\b", r"\bnpmrc\b", r"\bpypirc\b", r"\baws_access_key\b",
    ],
    "obfuscation": [
        r"\beval\b", r"\bFunction\s*\(", r"\batob\b", r"\bbtoa\b",
        r"\bbase64\b", r"\bfromCharCode\b", r"\bxor\b", r"\bobfuscat",
        r"\bminified\b",
    ],
    "downloader": [
        r"\bcurl\b", r"\bwget\b", r"\bdownload\b", r"\burlretrieve\b",
        r"\bremote\s+code\b", r"\bfetch\(.+https?://",
    ],
}
COMPILED_PATTERNS = {
    key: [re.compile(p, flags=re.IGNORECASE | re.MULTILINE) for p in pats]
    for key, pats in RISK_PATTERNS.items()
}


# ============================================================
# Utility helpers
# ============================================================

def build_session(timeout: int = 20) -> requests.Session:
    session = requests.Session()
    retry = Retry(
        total=4,
        backoff_factor=1.0,
        status_forcelist=[408, 429, 500, 502, 503, 504],
        allowed_methods=frozenset(["GET", "HEAD"]),
        raise_on_status=False,
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("https://", adapter)
    session.mount("http://", adapter)
    session.headers.update({"User-Agent": USER_AGENT})
    session.request_timeout = timeout
    return session


def request_json(session: requests.Session, url: str, timeout: Optional[int] = None) -> Optional[dict]:
    try:
        resp = session.get(url, timeout=timeout or session.request_timeout)
        if resp.status_code != 200:
            return None
        return resp.json()
    except Exception:
        return None


def request_text(session: requests.Session, url: str, timeout: Optional[int] = None) -> Optional[str]:
    try:
        resp = session.get(url, timeout=timeout or session.request_timeout)
        if resp.status_code != 200:
            return None
        return resp.text
    except Exception:
        return None


def safe_text(x) -> str:
    if x is None:
        return ""
    if isinstance(x, float) and math.isnan(x):
        return ""
    if isinstance(x, (list, tuple, set)):
        return " | ".join(v for v in (safe_text(v) for v in x) if v)
    if isinstance(x, dict):
        return " | ".join(
            f"{safe_text(k)}: {safe_text(v)}"
            for k, v in x.items()
            if safe_text(k) or safe_text(v)
        )
    return str(x).strip()


def compact_text(parts: Iterable[str], sep: str = " | ") -> str:
    vals = [safe_text(p) for p in parts]
    vals = [v for v in vals if v]
    return sep.join(vals)


def truthy_text(x) -> int:
    return int(bool(safe_text(x)))


def text_len(x) -> int:
    return len(safe_text(x))


def normalize_ecosystem(x: str) -> str:
    s = safe_text(x).lower()
    if s in {"npm", "node", "nodejs"}:
        return "npm"
    if s in {"pypi", "python"}:
        return "pypi"
    return s


def run_cmd(cmd: Sequence[str]) -> None:
    print("[RUN]", " ".join(map(str, cmd)))
    subprocess.run(list(cmd), check=True)


def ensure_repo(path: Path, repo_url: str, clone_if_missing: bool) -> Path:
    if path.exists():
        return path
    if not clone_if_missing:
        raise FileNotFoundError(f"Repository path does not exist: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    run_cmd(["git", "clone", "--depth", "1", repo_url, str(path)])
    return path


def ensure_binary_label(series: pd.Series) -> pd.Series:
    s = series.astype(str).str.strip().str.lower()
    mapping = {
        "1": 1, "malicious": 1, "true": 1, "yes": 1,
        "0": 0, "benign": 0, "false": 0, "no": 0,
    }
    out = s.map(mapping)
    if out.isna().any():
        bad = series[out.isna()].head(10).tolist()
        raise ValueError(f"Unrecognized labels found: {bad}")
    return out.astype(int)


def dedup_manifest(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["package_name_norm"] = out["package_name"].astype(str).str.strip().str.lower()
    out["ecosystem_norm"] = out["ecosystem"].astype(str).str.strip().str.lower()
    out = out.drop_duplicates(subset=["package_name_norm", "ecosystem_norm"]).reset_index(drop=True)
    return out.drop(columns=["package_name_norm", "ecosystem_norm"])


def ensure_columns(df: pd.DataFrame, cols: Sequence[str]) -> pd.DataFrame:
    out = df.copy()
    for c in cols:
        if c not in out.columns:
            out[c] = ""
    return out


# ============================================================
# Step 1: Malicious manifests
# ============================================================

def parse_datadog_manifest(repo_path: Path) -> pd.DataFrame:
    rows = []
    candidate_files = [repo_path / "samples" / "npm" / "manifest.json"]
    for manifest_path in candidate_files:
        if not manifest_path.exists():
            continue
        data = json.loads(manifest_path.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            if "samples" in data and isinstance(data["samples"], list):
                items = data["samples"]
            elif "packages" in data and isinstance(data["packages"], list):
                items = data["packages"]
            else:
                items = [data]
        elif isinstance(data, list):
            items = data
        else:
            items = []
        for item in items:
            if not isinstance(item, dict):
                continue
            pkg = safe_text(
                item.get("name")
                or item.get("package_name")
                or item.get("package")
                or item.get("pkg")
                or item.get("id")
            )
            if not pkg:
                continue
            rows.append({
                "package_name": pkg,
                "ecosystem": "npm",
                "label": "malicious",
                "source_name": "DataDog",
                "source_url": DATADOG_REPO_URL,
                "notes": safe_text(item.get("reason") or item.get("description") or ""),
            })
    return pd.DataFrame(rows)


def infer_ecosystem_from_osv(record: Dict) -> str:
    eco = safe_text(record.get("ecosystem"))
    if eco:
        return normalize_ecosystem(eco)
    affected = record.get("affected", [])
    if isinstance(affected, list):
        for aff in affected:
            if not isinstance(aff, dict):
                continue
            pkg = aff.get("package", {})
            if isinstance(pkg, dict):
                eco2 = safe_text(pkg.get("ecosystem"))
                if eco2:
                    return normalize_ecosystem(eco2)
    return ""


def infer_package_name_from_osv(record: Dict) -> str:
    affected = record.get("affected", [])
    if isinstance(affected, list):
        for aff in affected:
            if not isinstance(aff, dict):
                continue
            pkg = aff.get("package", {})
            if isinstance(pkg, dict):
                name = safe_text(pkg.get("name"))
                if name:
                    return name
    aliases = record.get("aliases", [])
    if isinstance(aliases, list):
        for alias in aliases:
            s = safe_text(alias)
            if s:
                return s
    return safe_text(record.get("id") or record.get("package_name") or record.get("name"))


def parse_ossf_records(repo_path: Path) -> pd.DataFrame:
    rows = []
    for jf in repo_path.rglob("*.json"):
        try:
            record = json.loads(jf.read_text(encoding="utf-8"))
        except Exception:
            continue
        if not isinstance(record, dict):
            continue
        ecosystem = infer_ecosystem_from_osv(record)
        if ecosystem != "npm":
            continue
        pkg = infer_package_name_from_osv(record)
        if not pkg:
            continue
        rows.append({
            "package_name": pkg,
            "ecosystem": "npm",
            "label": "malicious",
            "source_name": "OpenSSF",
            "source_url": OSSF_REPO_URL,
            "notes": safe_text(record.get("summary") or record.get("details") or record.get("id") or ""),
        })
    return pd.DataFrame(rows)


def cmd_build_malicious_manifest(args) -> None:
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    work_dir = Path(args.work_dir)
    datadog_repo = Path(args.datadog_repo) if args.datadog_repo else work_dir / "malicious-software-packages-dataset"
    ossf_repo = Path(args.ossf_repo) if args.ossf_repo else work_dir / "malicious-packages"

    datadog_repo = ensure_repo(datadog_repo, DATADOG_REPO_URL, args.clone_if_missing)
    ossf_repo = ensure_repo(ossf_repo, OSSF_REPO_URL, args.clone_if_missing)

    dd = parse_datadog_manifest(datadog_repo)
    ossf = parse_ossf_records(ossf_repo)
    df = pd.concat([dd, ossf], axis=0, ignore_index=True)
    if df.empty:
        raise RuntimeError("No malicious npm packages were collected.")
    df = dedup_manifest(df)
    if args.target and len(df) > args.target:
        df = df.sample(n=args.target, random_state=args.random_state).reset_index(drop=True)
    out_csv = out_dir / "malicious_packages_npm.csv"
    df.to_csv(out_csv, index=False)
    summary = {
        "rows": int(len(df)),
        "source_counts": df["source_name"].astype(str).value_counts().to_dict(),
        "ecosystem_counts": df["ecosystem"].astype(str).value_counts().to_dict(),
    }
    (out_dir / "malicious_manifest_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(f"[OK] Wrote malicious npm manifest to {out_csv}")


# ============================================================
# Step 2: Benign npm manifest
# ============================================================

def fetch_npm_search_page(session: requests.Session, text: str, size: int, offset: int) -> List[dict]:
    url = "https://registry.npmjs.org/-/v1/search"
    params = {"text": text, "size": size, "from": offset}
    try:
        resp = session.get(url, params=params, timeout=session.request_timeout)
        if resp.status_code != 200:
            return []
        payload = resp.json()
        return payload.get("objects", []) or []
    except Exception:
        return []


def collect_benign_candidates_from_search(
    session: requests.Session,
    target: int,
    random_state: int,
    pages_per_term: int,
    page_size: int,
    sleep_seconds: float,
) -> pd.DataFrame:
    rng = random.Random(random_state)
    terms = list(NPM_SEARCH_TERMS)
    rng.shuffle(terms)

    seen = set()
    rows = []
    for term in terms:
        for page_idx in range(pages_per_term):
            offset = page_idx * page_size
            objects = fetch_npm_search_page(session, term, page_size, offset)
            for obj in objects:
                package = obj.get("package", {}) if isinstance(obj, dict) else {}
                name = safe_text(package.get("name"))
                if not name:
                    continue
                key = name.lower()
                if key in seen:
                    continue
                seen.add(key)
                rows.append({
                    "package_name": name,
                    "ecosystem": "npm",
                    "label": "benign",
                    "source_name": "npm_search",
                    "source_url": "https://registry.npmjs.org/-/v1/search",
                    "notes": safe_text(package.get("description")),
                })
                if len(rows) >= target:
                    return pd.DataFrame(rows)
            time.sleep(sleep_seconds)
    return pd.DataFrame(rows)


def cmd_build_benign_manifest(args) -> None:
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    session = build_session(timeout=args.timeout)

    df = collect_benign_candidates_from_search(
        session=session,
        target=args.target,
        random_state=args.random_state,
        pages_per_term=args.pages_per_term,
        page_size=args.page_size,
        sleep_seconds=args.sleep_seconds,
    )
    if df.empty:
        raise RuntimeError("No benign npm manifest candidates were collected from npm search.")
    df = dedup_manifest(df)
    out_csv = out_dir / "benign_packages_npm.csv"
    df.to_csv(out_csv, index=False)
    summary = {
        "rows": int(len(df)),
        "source_counts": df["source_name"].astype(str).value_counts().to_dict(),
    }
    (out_dir / "benign_manifest_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(f"[OK] Wrote benign npm manifest to {out_csv}")


# ============================================================
# Step 3: Live corpus enrichment
# ============================================================

def pick_latest_version(meta: dict) -> Tuple[str, dict]:
    versions = meta.get("versions", {}) or {}
    dist_tags = meta.get("dist-tags", {}) or {}
    latest = safe_text(dist_tags.get("latest"))
    if latest and latest in versions:
        return latest, versions[latest]
    if versions:
        sorted_versions = sorted(versions.keys())
        key = sorted_versions[-1]
        return key, versions[key]
    return "", {}


def extract_project_urls(version_record: dict) -> str:
    repository = version_record.get("repository")
    repository_url = ""
    if isinstance(repository, dict):
        repository_url = safe_text(repository.get("url"))
    elif isinstance(repository, str):
        repository_url = safe_text(repository)

    bugs = version_record.get("bugs")
    bugs_text = safe_text(bugs)
    homepage = safe_text(version_record.get("homepage"))
    return compact_text([homepage, repository_url, bugs_text])


def extract_repository_url(version_record: dict) -> str:
    repository = version_record.get("repository")
    if isinstance(repository, dict):
        return safe_text(repository.get("url"))
    return safe_text(repository)


def extract_author(version_record: dict) -> str:
    return safe_text(version_record.get("author"))


def extract_maintainers(meta: dict) -> str:
    return safe_text(meta.get("maintainers"))


def extract_license(version_record: dict) -> str:
    lic = version_record.get("license")
    if isinstance(lic, dict):
        return safe_text(lic.get("type") or lic.get("name"))
    return safe_text(lic)


def extract_requires_dist(version_record: dict) -> str:
    deps = version_record.get("dependencies")
    return safe_text(deps)


def extract_scripts_text(version_record: dict) -> str:
    scripts = version_record.get("scripts")
    return safe_text(scripts)


def pick_created_time(meta: dict, version: str) -> str:
    t = meta.get("time", {}) or {}
    version_time = safe_text(t.get(version))
    if version_time:
        return version_time
    created = safe_text(t.get("created"))
    if created:
        return created
    modified = safe_text(t.get("modified"))
    return modified


def is_text_member(name: str) -> bool:
    lowered = name.lower()
    good_suffixes = (
        ".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs", ".json", ".md", ".txt",
        ".yml", ".yaml", ".html", ".css", ".sh"
    )
    if lowered.endswith(good_suffixes):
        return True
    base = Path(lowered).name
    return base in {"package.json", "readme", "readme.md", "license", "install"}


def scan_npm_tarball_text(
    session: requests.Session,
    tarball_url: str,
    max_files: int,
    max_bytes: int,
) -> Tuple[str, Dict[str, int]]:
    if not tarball_url:
        return "", {"files_scanned": 0, "bytes_scanned": 0}

    try:
        resp = session.get(tarball_url, timeout=session.request_timeout, stream=True)
        if resp.status_code != 200:
            return "", {"files_scanned": 0, "bytes_scanned": 0}
        content = resp.content
    except Exception:
        return "", {"files_scanned": 0, "bytes_scanned": 0}

    files_scanned = 0
    bytes_scanned = 0
    texts: List[str] = []

    try:
        bio = io.BytesIO(content)
        with tarfile.open(fileobj=bio, mode="r:gz") as tf:
            for member in tf.getmembers():
                if files_scanned >= max_files or bytes_scanned >= max_bytes:
                    break
                if not member.isfile():
                    continue
                if not is_text_member(member.name):
                    continue
                fileobj = tf.extractfile(member)
                if fileobj is None:
                    continue
                raw = fileobj.read(min(member.size, max_bytes - bytes_scanned))
                bytes_scanned += len(raw)
                files_scanned += 1
                try:
                    txt = raw.decode("utf-8", errors="ignore")
                except Exception:
                    txt = ""
                if txt:
                    texts.append(f"\n### FILE: {member.name}\n{txt[:50000]}")
    except Exception:
        return "", {"files_scanned": files_scanned, "bytes_scanned": bytes_scanned}

    return "\n".join(texts), {"files_scanned": files_scanned, "bytes_scanned": bytes_scanned}


def fetch_npm_metadata(session: requests.Session, package_name: str) -> Optional[dict]:
    url = f"https://registry.npmjs.org/{package_name}"
    return request_json(session, url)


def enrich_single_npm_package(
    session: requests.Session,
    package_name: str,
    label: str,
    source_name: str,
    source_url: str,
    notes: str,
    include_tarball_scan: bool,
    tarball_max_files: int,
    tarball_max_bytes: int,
    sleep_seconds: float,
) -> Dict[str, str]:
    meta = fetch_npm_metadata(session, package_name)
    if not meta:
        return {
            "package_name": package_name,
            "ecosystem": "npm",
            "label": label,
            "summary": "",
            "description": "",
            "readme": "",
            "keywords": "",
            "homepage": "",
            "project_urls": "",
            "repository_url": "",
            "author": "",
            "maintainers": "",
            "license": "",
            "requires_dist": "",
            "scripts_text": "",
            "dist_urls": "",
            "artifact_text": "",
            "created_time": "",
            "latest_version": "",
            "source_name": source_name,
            "source_url": source_url,
            "notes": notes,
            "artifact_scan_files": 0,
            "artifact_scan_bytes": 0,
            "metadata_fetch_ok": 0,
        }

    version, version_record = pick_latest_version(meta)
    readme = safe_text(meta.get("readme"))
    tarball_url = safe_text((version_record.get("dist") or {}).get("tarball"))
    artifact_text = ""
    scan_stats = {"files_scanned": 0, "bytes_scanned": 0}
    if include_tarball_scan and tarball_url:
        artifact_text, scan_stats = scan_npm_tarball_text(
            session=session,
            tarball_url=tarball_url,
            max_files=tarball_max_files,
            max_bytes=tarball_max_bytes,
        )

    record = {
        "package_name": package_name,
        "ecosystem": "npm",
        "label": label,
        "summary": safe_text(version_record.get("description") or meta.get("description")),
        "description": safe_text(version_record.get("description") or meta.get("description")),
        "readme": readme,
        "keywords": safe_text(version_record.get("keywords")),
        "homepage": safe_text(version_record.get("homepage")),
        "project_urls": extract_project_urls(version_record),
        "repository_url": extract_repository_url(version_record),
        "author": extract_author(version_record),
        "maintainers": extract_maintainers(meta),
        "license": extract_license(version_record),
        "requires_dist": extract_requires_dist(version_record),
        "scripts_text": extract_scripts_text(version_record),
        "dist_urls": tarball_url,
        "artifact_text": artifact_text,
        "created_time": pick_created_time(meta, version),
        "latest_version": version,
        "source_name": source_name,
        "source_url": source_url,
        "notes": notes,
        "artifact_scan_files": scan_stats["files_scanned"],
        "artifact_scan_bytes": scan_stats["bytes_scanned"],
        "metadata_fetch_ok": 1,
    }
    time.sleep(sleep_seconds)
    return record


def sample_manifest(df: pd.DataFrame, label: str, n: Optional[int], random_state: int) -> pd.DataFrame:
    sub = df[df["label"].astype(str).str.lower() == label.lower()].copy()
    if n is not None and len(sub) > n:
        sub = sub.sample(n=n, random_state=random_state)
    return sub.reset_index(drop=True)


def cmd_build_corpus_live(args) -> None:
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    mal_df = pd.read_csv(args.malicious_manifest)
    ben_df = pd.read_csv(args.benign_manifest)
    mal_df = ensure_columns(mal_df, ["package_name", "ecosystem", "label", "source_name", "source_url", "notes"])
    ben_df = ensure_columns(ben_df, ["package_name", "ecosystem", "label", "source_name", "source_url", "notes"])

    mal_df["ecosystem"] = mal_df["ecosystem"].map(normalize_ecosystem)
    ben_df["ecosystem"] = ben_df["ecosystem"].map(normalize_ecosystem)

    mal_df = mal_df[mal_df["ecosystem"] == "npm"].copy()
    ben_df = ben_df[ben_df["ecosystem"] == "npm"].copy()

    mal_df = sample_manifest(mal_df, "malicious", args.max_malicious, args.random_state)
    ben_df = sample_manifest(ben_df, "benign", args.max_benign, args.random_state)
    manifest = pd.concat([mal_df, ben_df], axis=0, ignore_index=True)
    manifest = dedup_manifest(manifest)

    session = build_session(timeout=args.timeout)
    rows = []
    total = len(manifest)
    for idx, row in manifest.iterrows():
        rec = enrich_single_npm_package(
            session=session,
            package_name=safe_text(row["package_name"]),
            label=safe_text(row["label"]),
            source_name=safe_text(row["source_name"]),
            source_url=safe_text(row["source_url"]),
            notes=safe_text(row["notes"]),
            include_tarball_scan=not args.skip_tarball_scan,
            tarball_max_files=args.tarball_max_files,
            tarball_max_bytes=args.tarball_max_bytes,
            sleep_seconds=args.sleep_seconds,
        )
        rows.append(rec)
        if (idx + 1) % 100 == 0 or (idx + 1) == total:
            print(f"[INFO] Enriched {idx + 1}/{total} rows.")

    corpus = pd.DataFrame(rows)
    corpus = ensure_columns(corpus, DEFAULT_TEXT_COLUMNS + ["artifact_text", "created_time", "latest_version"])
    corpus.to_csv(out_dir / "normalized_corpus_live.csv", index=False)

    manifest_summary = {
        "rows": int(len(corpus)),
        "label_counts": corpus["label"].astype(str).value_counts(dropna=False).to_dict(),
        "metadata_fetch_ok_sum": int(corpus["metadata_fetch_ok"].sum()) if "metadata_fetch_ok" in corpus.columns else None,
        "tarball_scan_used": not args.skip_tarball_scan,
    }
    (out_dir / "corpus_summary.json").write_text(
        json.dumps(manifest_summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(f"[OK] Wrote live corpus to {out_dir}")


# ============================================================
# Step 4: Feature construction
# ============================================================

def count_pattern_hits(text: str, compiled_patterns: List[re.Pattern]) -> int:
    return sum(1 for pat in compiled_patterns if pat.search(text))


def has_pattern(text: str, compiled_patterns: List[re.Pattern]) -> int:
    return int(any(pat.search(text) for pat in compiled_patterns))


def make_intent_text(row: pd.Series) -> str:
    return compact_text([
        row.get("package_name"),
        row.get("summary"),
        row.get("description"),
        row.get("keywords"),
        row.get("homepage"),
        row.get("repository_url"),
    ])


def make_behavior_text(row: pd.Series) -> str:
    return compact_text([
        row.get("artifact_text"),
        row.get("readme"),
        row.get("scripts_text"),
        row.get("project_urls"),
        row.get("dist_urls"),
        row.get("requires_dist"),
    ])


def infer_role(intent_text: str) -> str:
    text = safe_text(intent_text).lower()
    scores = {role: sum(1 for kw in kws if kw in text) for role, kws in ROLE_KEYWORDS.items()}
    best_role = max(scores.items(), key=lambda kv: kv[1])[0]
    if scores[best_role] == 0:
        return "build_tooling"
    return best_role


def incompatibility(obs: float, allowance: float) -> float:
    return max(0.0, float(obs) - float(allowance))


def compute_discordance(row: pd.Series) -> Tuple[float, Dict[str, float]]:
    role = row["inferred_role"]
    allowances = ROLE_ALLOWANCES[role]
    dims = [
        "installation_hook", "shell_exec", "network_access", "environment_access",
        "credential_access", "obfuscation", "downloader", "suspicious_hits_norm",
    ]
    parts: Dict[str, float] = {}
    total = 0.0
    for dim in dims:
        allowance_key = "suspicious_hits" if dim == "suspicious_hits_norm" else dim
        obs = float(row[dim])
        inc = incompatibility(obs, allowances[allowance_key])
        weighted = DISCORDANCE_WEIGHTS[allowance_key] * inc
        parts[f"discordance_{allowance_key}"] = weighted
        total += weighted
    return total, parts


def rebuild_features_from_source(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out = ensure_columns(out, DEFAULT_TEXT_COLUMNS + ["artifact_text"])
    for col in DEFAULT_TEXT_COLUMNS + ["artifact_text", "label", "ecosystem", "package_name", "created_time"]:
        if col in out.columns:
            out[col] = out[col].map(safe_text)

    out["intent_text"] = out.apply(make_intent_text, axis=1)
    out["behavior_text"] = out.apply(make_behavior_text, axis=1)

    # Metadata branch: 13 features total.
    out["desc_present"] = out["description"].map(truthy_text)
    out["readme_present"] = out["readme"].map(truthy_text)
    out["keywords_present"] = out["keywords"].map(truthy_text)
    out["homepage_present"] = out["homepage"].map(truthy_text)
    out["project_urls_present"] = out["project_urls"].map(truthy_text)
    out["repository_present"] = out["repository_url"].map(truthy_text)
    out["author_present"] = out["author"].map(truthy_text)
    out["maintainers_present"] = out["maintainers"].map(truthy_text)
    out["license_present"] = out["license"].map(truthy_text)

    out["desc_len"] = out["description"].map(text_len)
    out["readme_len"] = out["readme"].map(text_len)
    out["keywords_len"] = out["keywords"].map(text_len)
    out["intent_len"] = out["intent_text"].map(text_len)

    metadata_presence_cols = [
        "desc_present", "readme_present", "keywords_present", "homepage_present",
        "project_urls_present", "repository_present", "author_present",
        "maintainers_present", "license_present",
    ]
    out["metadata_presence_score"] = out[metadata_presence_cols].sum(axis=1)

    # Behavior branch: 8 features total.
    beh_text = out["behavior_text"].fillna("")
    out["installation_hook"] = beh_text.map(lambda x: has_pattern(x, COMPILED_PATTERNS["installation_hook"]))
    out["shell_exec"] = beh_text.map(lambda x: has_pattern(x, COMPILED_PATTERNS["shell_exec"]))
    out["network_access"] = beh_text.map(lambda x: has_pattern(x, COMPILED_PATTERNS["network_access"]))
    out["environment_access"] = beh_text.map(lambda x: has_pattern(x, COMPILED_PATTERNS["environment_access"]))
    out["credential_access"] = beh_text.map(lambda x: has_pattern(x, COMPILED_PATTERNS["credential_access"]))
    out["obfuscation"] = beh_text.map(lambda x: has_pattern(x, COMPILED_PATTERNS["obfuscation"]))
    out["downloader"] = beh_text.map(lambda x: has_pattern(x, COMPILED_PATTERNS["downloader"]))
    out["suspicious_hits"] = beh_text.map(
        lambda x: sum(count_pattern_hits(x, COMPILED_PATTERNS[k]) for k in COMPILED_PATTERNS.keys())
    )
    out["behavior_len"] = out["behavior_text"].map(text_len)
    out["suspicious_hits_norm"] = out["suspicious_hits"].map(lambda v: min(float(v) / 10.0, 1.0))

    # Discordance branch: 9 features total.
    out["inferred_role"] = out["intent_text"].map(infer_role)
    disc = out.apply(compute_discordance, axis=1)
    out["discordance_score"] = disc.map(lambda x: x[0])
    disc_parts = pd.DataFrame([x[1] for x in disc.tolist()])
    out = pd.concat([out.reset_index(drop=True), disc_parts.reset_index(drop=True)], axis=1)
    out = out.loc[:, ~out.columns.duplicated()]
    return out


def build_feature_groups() -> Dict[str, List[str]]:
    metadata_cols = [
        "desc_present", "readme_present", "keywords_present", "homepage_present",
        "project_urls_present", "repository_present", "author_present",
        "maintainers_present", "license_present", "desc_len", "readme_len",
        "keywords_len", "intent_len",
    ]
    behavior_cols = [
        "installation_hook", "shell_exec", "network_access", "environment_access",
        "credential_access", "obfuscation", "downloader", "suspicious_hits",
    ]
    discordance_cols = [
        "discordance_score",
        "discordance_installation_hook",
        "discordance_shell_exec",
        "discordance_network_access",
        "discordance_environment_access",
        "discordance_credential_access",
        "discordance_obfuscation",
        "discordance_downloader",
        "discordance_suspicious_hits",
    ]
    return {
        "PURE_METADATA_COLS": metadata_cols,
        "PURE_BEHAVIOR_COLS": behavior_cols,
        "PURE_FULL_COLS": metadata_cols + behavior_cols,
        "DISCORDANCE_COLS": discordance_cols,
        "FULL_WITH_DISCORDANCE_COLS": metadata_cols + behavior_cols + discordance_cols,
    }


def build_metadata_groups(df: pd.DataFrame) -> Dict[str, List[str]]:
    presence_cols = [
        "desc_present", "readme_present", "keywords_present", "homepage_present",
        "project_urls_present", "repository_present", "author_present",
        "maintainers_present", "license_present",
    ]
    length_cols = ["desc_len", "readme_len", "keywords_len", "intent_len"]
    availability_cols = ["metadata_presence_score"]
    presentation_cols = [
        "desc_present", "keywords_present", "homepage_present",
        "project_urls_present", "repository_present", "desc_len",
        "keywords_len", "intent_len",
    ]
    profile_cols = [
        "author_present", "maintainers_present", "license_present",
        "readme_present", "readme_len",
    ]
    candidates = {
        "Metadata-Presence": presence_cols,
        "Metadata-Length": length_cols,
        "Metadata-AvailabilityScore": availability_cols,
        "Metadata-PresentationFacing": presentation_cols,
        "Metadata-ProfileLike": profile_cols,
        "Metadata-All": presence_cols + length_cols,
    }
    groups: Dict[str, List[str]] = {}
    for name, cols in candidates.items():
        present = [c for c in cols if c in df.columns]
        if present:
            groups[name] = present
    if not groups:
        raise ValueError("Could not build metadata groups from features.csv columns.")
    return groups


def cmd_build_features(args) -> None:
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(args.input_corpus)
    feat = rebuild_features_from_source(df)
    feature_groups = build_feature_groups()
    metadata_groups = build_metadata_groups(feat)

    feat.to_csv(out_dir / "features.csv", index=False)
    (out_dir / "feature_groups.json").write_text(
        json.dumps(feature_groups, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    (out_dir / "metadata_groups.json").write_text(
        json.dumps(metadata_groups, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    summary = {
        "rows": int(len(feat)),
        "label_counts": feat["label"].astype(str).value_counts(dropna=False).to_dict(),
        "feature_group_sizes": {k: len(v) for k, v in feature_groups.items()},
        "metadata_group_sizes": {k: len(v) for k, v in metadata_groups.items()},
        "role_counts": feat["inferred_role"].astype(str).value_counts(dropna=False).to_dict(),
    }
    (out_dir / "feature_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(f"[OK] Wrote features to {out_dir}")


# ============================================================
# Common modeling helpers
# ============================================================

def get_models(random_state: int = 42) -> Dict[str, object]:
    return {
        "Logistic Regression": Pipeline([
            ("scaler", StandardScaler()),
            ("clf", LogisticRegression(max_iter=2000, random_state=random_state)),
        ]),
        "Random Forest": RandomForestClassifier(
            n_estimators=300,
            random_state=random_state,
            n_jobs=-1,
            class_weight=None,
        ),
    }


def compute_metrics(y_true: pd.Series, y_pred: np.ndarray) -> Dict[str, float]:
    return {
        "Accuracy": float(accuracy_score(y_true, y_pred)),
        "Precision": float(precision_score(y_true, y_pred, zero_division=0)),
        "Recall": float(recall_score(y_true, y_pred, zero_division=0)),
        "F1": float(f1_score(y_true, y_pred, zero_division=0)),
    }


def stratify_labels(df: pd.DataFrame) -> pd.Series:
    y = ensure_binary_label(df["label"])
    eco = df["ecosystem"].astype(str)
    return y.astype(str) + "__" + eco


def run_split_experiment(
    df: pd.DataFrame,
    feature_sets: Dict[str, List[str]],
    random_state: int,
    test_size: float,
) -> pd.DataFrame:
    work = df.copy()
    work["y"] = ensure_binary_label(work["label"])

    train_df, test_df = train_test_split(
        work,
        test_size=test_size,
        random_state=random_state,
        stratify=stratify_labels(work),
    )

    rows = []
    for fs_name, cols in feature_sets.items():
        missing = [c for c in cols if c not in work.columns]
        if missing:
            raise ValueError(f"Missing columns for feature set {fs_name}: {missing}")
        X_train = train_df[cols].fillna(0)
        X_test = test_df[cols].fillna(0)
        y_train = train_df["y"]
        y_test = test_df["y"]

        for model_name, model in get_models(random_state=random_state).items():
            model.fit(X_train, y_train)
            y_pred = model.predict(X_test)
            rows.append({
                "Feature Set": fs_name,
                "Model": model_name,
                "#Features": len(cols),
                **compute_metrics(y_test, y_pred),
            })
    result = pd.DataFrame(rows)
    order = ["Metadata-only", "Full model", "Behavior-only", "Discordance-only", "Full+Discordance"]
    result["__order"] = result["Feature Set"].map({k: i for i, k in enumerate(order)}).fillna(999)
    result = result.sort_values(["__order", "Model"]).drop(columns="__order").reset_index(drop=True)
    return result


def make_bins(series: pd.Series, edges: List[int]) -> pd.Series:
    return pd.cut(series.fillna(0), bins=edges, include_lowest=True, right=False).astype(str)


def build_matched_availability_subset(df: pd.DataFrame, random_state: int = 42) -> pd.DataFrame:
    work = df.copy()
    work["y"] = ensure_binary_label(work["label"])

    len_edges = [-1, 0, 20, 100, 500, 2000, 10000, 10**9]
    meta_edges = [-1, 0, 1, 3, 5, 7, 9, 20]

    work["bin_metadata_presence_score"] = make_bins(work["metadata_presence_score"], meta_edges)
    work["bin_desc_len"] = make_bins(work["desc_len"], len_edges)
    work["bin_readme_len"] = make_bins(work["readme_len"], len_edges)
    work["bin_intent_len"] = make_bins(work["intent_len"], len_edges)
    work["bin_behavior_len"] = make_bins(work["behavior_len"], len_edges)

    group_cols = [
        "ecosystem", "bin_metadata_presence_score", "bin_desc_len",
        "bin_readme_len", "bin_intent_len", "bin_behavior_len",
    ]
    matched_parts = []
    for _, sub in work.groupby(group_cols, dropna=False):
        benign = sub[sub["y"] == 0]
        malicious = sub[sub["y"] == 1]
        n = min(len(benign), len(malicious))
        if n <= 0:
            continue
        matched_parts.append(pd.concat([
            benign.sample(n=n, random_state=random_state),
            malicious.sample(n=n, random_state=random_state),
        ], axis=0))
    if not matched_parts:
        raise RuntimeError("Matched subset construction produced no matched cells.")
    return pd.concat(matched_parts, axis=0).sample(frac=1.0, random_state=random_state).reset_index(drop=True)


# ============================================================
# Step 5: Clean + matched
# ============================================================

def cmd_run_clean_matched(args) -> None:
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    df = pd.read_csv(args.features_csv)
    groups = json.loads(Path(args.feature_groups_json).read_text(encoding="utf-8"))
    feature_sets = {
        "Metadata-only": groups["PURE_METADATA_COLS"],
        "Behavior-only": groups["PURE_BEHAVIOR_COLS"],
        "Full model": groups["PURE_FULL_COLS"],
        "Discordance-only": groups["DISCORDANCE_COLS"],
        "Full+Discordance": groups["FULL_WITH_DISCORDANCE_COLS"],
    }

    clean_results = run_split_experiment(df, feature_sets, args.random_state, args.test_size)
    matched_df = build_matched_availability_subset(df, args.random_state)
    matched_results = run_split_experiment(matched_df, feature_sets, args.random_state, args.test_size)

    clean_results.to_csv(out_dir / "clean_results.csv", index=False)
    matched_results.to_csv(out_dir / "matched_results.csv", index=False)
    matched_df.to_csv(out_dir / "matched_subset.csv", index=False)

    summary = {
        "full_rows": int(len(df)),
        "matched_rows": int(len(matched_df)),
        "matched_label_counts": matched_df["label"].astype(str).value_counts(dropna=False).to_dict(),
        "matched_ecosystem_counts": matched_df["ecosystem"].astype(str).value_counts(dropna=False).to_dict(),
    }
    (out_dir / "experiment_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(f"[OK] Wrote clean/matched results to {out_dir}")


# ============================================================
# Step 6: Deception attacks
# ============================================================

ATTACK_VARIANTS = [
    "A0_Clean",
    "A1_BlankBasic",
    "A2_IntentSpoof",
    "A3_RoleSpoofFull",
    "A4_SelectiveDeception",
    "A5_BenignReadmePrefix",
]


def apply_attack(df_test_source: pd.DataFrame, attack_name: str) -> pd.DataFrame:
    attacked = df_test_source.copy()
    y = ensure_binary_label(attacked["label"])
    mal_mask = (y == 1)

    # Cast attack-touched columns to object to avoid pandas dtype warnings.
    touched = list(set(BASIC_BLANK_FIELDS + [
        "summary", "description", "keywords", "homepage", "project_urls",
        "repository_url", "readme", "scripts_text", "requires_dist"
    ]))
    for col in touched:
        if col in attacked.columns:
            attacked[col] = attacked[col].astype(object)

    if attack_name == "A0_Clean":
        return attacked

    if attack_name == "A1_BlankBasic":
        for col in BASIC_BLANK_FIELDS:
            if col in attacked.columns:
                attacked.loc[mal_mask, col] = ""
        return attacked

    if attack_name == "A2_IntentSpoof":
        spoof = ROLE_SPOOF_SNIPPETS["utility"]
        for col in ["summary", "description", "keywords"]:
            if col in attacked.columns:
                attacked.loc[mal_mask, col] = spoof[col]
        if "homepage" in attacked.columns:
            attacked.loc[mal_mask, "homepage"] = "https://example.org/utility-toolkit"
        if "project_urls" in attacked.columns:
            attacked.loc[mal_mask, "project_urls"] = "Homepage https://example.org/utility-toolkit"
        return attacked

    if attack_name == "A3_RoleSpoofFull":
        spoof = ROLE_SPOOF_SNIPPETS["docs"]
        for col in ["summary", "description", "keywords"]:
            if col in attacked.columns:
                attacked.loc[mal_mask, col] = spoof[col]
        if "homepage" in attacked.columns:
            attacked.loc[mal_mask, "homepage"] = "https://example.org/docs-format"
        if "project_urls" in attacked.columns:
            attacked.loc[mal_mask, "project_urls"] = "Homepage https://example.org/docs-format"
        if "repository_url" in attacked.columns:
            attacked.loc[mal_mask, "repository_url"] = "https://github.com/example/docs-format"
        if "readme" in attacked.columns:
            attacked.loc[mal_mask, "readme"] = (
                spoof["readme_prefix"] + attacked.loc[mal_mask, "readme"].map(safe_text)
            )
        if "scripts_text" in attacked.columns:
            attacked.loc[mal_mask, "scripts_text"] = "format docs render markdown"
        if "requires_dist" in attacked.columns:
            attacked.loc[mal_mask, "requires_dist"] = "markdown pyyaml click"
        return attacked

    if attack_name == "A4_SelectiveDeception":
        spoof = ROLE_SPOOF_SNIPPETS["network"]
        if "summary" in attacked.columns:
            attacked.loc[mal_mask, "summary"] = spoof["summary"]
        if "keywords" in attacked.columns:
            attacked.loc[mal_mask, "keywords"] = spoof["keywords"]
        if "readme" in attacked.columns:
            attacked.loc[mal_mask, "readme"] = (
                spoof["readme_prefix"] + attacked.loc[mal_mask, "readme"].map(safe_text)
            )
        if "project_urls" in attacked.columns:
            attacked.loc[mal_mask, "project_urls"] = "Homepage https://example.org/api-helper"
        return attacked

    if attack_name == "A5_BenignReadmePrefix":
        spoof = ROLE_SPOOF_SNIPPETS["utility"]
        if "readme" in attacked.columns:
            attacked.loc[mal_mask, "readme"] = (
                spoof["readme_prefix"] + attacked.loc[mal_mask, "readme"].map(safe_text)
            )
        return attacked

    raise ValueError(f"Unknown attack: {attack_name}")


def get_clean_split(df: pd.DataFrame, random_state: int, test_size: float) -> Tuple[pd.DataFrame, pd.DataFrame]:
    work = df.copy()
    train_df, test_df = train_test_split(
        work,
        test_size=test_size,
        random_state=random_state,
        stratify=stratify_labels(work),
    )
    return train_df.reset_index(drop=True), test_df.reset_index(drop=True)


def train_clean_models(
    train_df: pd.DataFrame,
    feature_sets: Dict[str, List[str]],
    random_state: int,
) -> Dict[Tuple[str, str], object]:
    work = train_df.copy()
    work["y"] = ensure_binary_label(work["label"])
    trained = {}
    for fs_name, cols in feature_sets.items():
        X_train = work[cols].fillna(0)
        y_train = work["y"]
        for model_name, model in get_models(random_state=random_state).items():
            model.fit(X_train, y_train)
            trained[(fs_name, model_name)] = model
    return trained


def evaluate_models_on_test(
    test_df: pd.DataFrame,
    feature_sets: Dict[str, List[str]],
    trained_models: Dict[Tuple[str, str], object],
) -> pd.DataFrame:
    work = test_df.copy()
    work["y"] = ensure_binary_label(work["label"])
    rows = []
    for fs_name, cols in feature_sets.items():
        X_test = work[cols].fillna(0)
        y_test = work["y"]
        for model_name in ["Logistic Regression", "Random Forest"]:
            model = trained_models[(fs_name, model_name)]
            y_pred = model.predict(X_test)
            rows.append({
                "Feature Set": fs_name,
                "Model": model_name,
                "#Features": len(cols),
                **compute_metrics(y_test, y_pred),
            })
    result = pd.DataFrame(rows)
    order = ["Metadata-only", "Full model", "Behavior-only", "Discordance-only", "Full+Discordance"]
    result["__order"] = result["Feature Set"].map({k: i for i, k in enumerate(order)}).fillna(999)
    result = result.sort_values(["__order", "Model"]).drop(columns="__order").reset_index(drop=True)
    return result


def feature_change_diagnostics(
    clean_df: pd.DataFrame,
    attacked_df: pd.DataFrame,
    feature_groups_json: Dict[str, List[str]],
    attack_name: str,
) -> pd.DataFrame:
    rows = []
    clean_feat = rebuild_features_from_source(clean_df)
    attacked_feat = rebuild_features_from_source(attacked_df)
    for group_name, cols in feature_groups_json.items():
        present = [c for c in cols if c in clean_feat.columns and c in attacked_feat.columns]
        if not present:
            continue
        clean_arr = clean_feat[present].fillna(0).to_numpy(dtype=float)
        attacked_arr = attacked_feat[present].fillna(0).to_numpy(dtype=float)
        mean_abs_delta = float(np.mean(np.abs(attacked_arr - clean_arr)))
        rows.append({
            "Attack": attack_name,
            "Feature Group": group_name,
            "MeanAbsDelta": mean_abs_delta,
            "#Features": len(present),
        })
    return pd.DataFrame(rows)


def cmd_run_attacks(args) -> None:
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    attacked_sets_dir = out_dir / "attacked_feature_sets"
    attacked_sets_dir.mkdir(parents=True, exist_ok=True)

    df_feat = pd.read_csv(args.features_csv)
    groups = json.loads(Path(args.feature_groups_json).read_text(encoding="utf-8"))
    feature_sets = {
        "Metadata-only": groups["PURE_METADATA_COLS"],
        "Behavior-only": groups["PURE_BEHAVIOR_COLS"],
        "Full model": groups["PURE_FULL_COLS"],
        "Discordance-only": groups["DISCORDANCE_COLS"],
        "Full+Discordance": groups["FULL_WITH_DISCORDANCE_COLS"],
    }

    train_df, clean_test_df = get_clean_split(df_feat, args.random_state, args.test_size)
    trained_models = train_clean_models(train_df, feature_sets, args.random_state)

    attack_rows = []
    diag_rows = []

    for attack_name in ATTACK_VARIANTS:
        attacked_source = apply_attack(clean_test_df, attack_name)
        attacked_feat = rebuild_features_from_source(attacked_source)
        result_df = evaluate_models_on_test(attacked_feat, feature_sets, trained_models)
        result_df.insert(0, "Attack", attack_name)
        attack_rows.append(result_df)

        diag_rows.append(feature_change_diagnostics(clean_test_df, attacked_source, groups, attack_name))
        attacked_feat.to_csv(attacked_sets_dir / f"{attack_name}_features.csv", index=False)

    attack_results = pd.concat(attack_rows, axis=0).reset_index(drop=True)
    diagnostics = pd.concat(diag_rows, axis=0).reset_index(drop=True)

    attack_results.to_csv(out_dir / "attack_results.csv", index=False)
    diagnostics.to_csv(out_dir / "attack_feature_change_diagnostics.csv", index=False)
    summary = {
        "attacks": ATTACK_VARIANTS,
        "rows": int(len(attack_results)),
    }
    (out_dir / "attack_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(f"[OK] Wrote attack outputs to {out_dir}")


# ============================================================
# Step 7: Temporal split
# ============================================================

def load_feature_sets(feature_groups_json: Path) -> Dict[str, List[str]]:
    groups = json.loads(feature_groups_json.read_text(encoding="utf-8"))
    return {
        "Metadata-only": groups["PURE_METADATA_COLS"],
        "Behavior-only": groups["PURE_BEHAVIOR_COLS"],
        "Full model": groups["PURE_FULL_COLS"],
        "Discordance-only": groups["DISCORDANCE_COLS"],
        "Full+Discordance": groups["FULL_WITH_DISCORDANCE_COLS"],
    }


def pick_time_column(df: pd.DataFrame) -> str:
    candidates = ["created_time", "latest_time"]
    for col in candidates:
        if col in df.columns:
            ts = pd.to_datetime(df[col], errors="coerce", utc=True)
            if ts.notna().sum() > 0:
                return col
    raise ValueError("No usable time column found in corpus. Expected one of: created_time, latest_time")


def merge_features_with_corpus(
    features_df: pd.DataFrame,
    corpus_df: pd.DataFrame,
) -> Tuple[pd.DataFrame, List[str], str]:
    """
    Merge features with corpus timestamps using the best available key set.
    Avoid duplicate created_time/latest_time suffix problems by converting
    the chosen corpus time column into __time__ before merge.
    """
    time_col = pick_time_column(corpus_df)

    corpus = corpus_df.copy()
    corpus["__time__"] = pd.to_datetime(corpus[time_col], errors="coerce", utc=True)
    corpus = corpus[corpus["__time__"].notna()].copy()

    merge_candidates = [
        ["package_name", "ecosystem", "label"],
        ["package_name", "ecosystem"],
        ["package_name"],
    ]

    best_merged = None
    best_keys = None
    best_coverage = -1.0

    for keys in merge_candidates:
        if not all(k in features_df.columns for k in keys):
            continue
        if not all(k in corpus.columns for k in keys):
            continue

        temp = features_df.merge(
            corpus[keys + ["__time__"]],
            on=keys,
            how="left",
        )
        coverage = temp["__time__"].notna().mean()

        if coverage > best_coverage:
            best_coverage = coverage
            best_merged = temp
            best_keys = keys

    if best_merged is None:
        raise ValueError(
            "Could not merge features with corpus. "
            "No compatible key set found among package_name/ecosystem/label."
        )

    if best_coverage < 0.80:
        raise ValueError(
            f"Merge coverage too low ({best_coverage:.2%}). "
            f"Best keys were {best_keys}. Check that features.csv and corpus.csv match."
        )

    merged = best_merged[best_merged["__time__"].notna()].copy()
    return merged, best_keys, time_col


def run_temporal(
    features_df: pd.DataFrame,
    corpus_df: pd.DataFrame,
    feature_sets: Dict[str, List[str]],
    random_state: int,
) -> Tuple[pd.DataFrame, Dict[str, object]]:
    merged_df, merge_keys, time_col = merge_features_with_corpus(features_df, corpus_df)

    merged_df = merged_df.sort_values("__time__").reset_index(drop=True)
    cutoff = merged_df["__time__"].quantile(0.75)

    train_df = merged_df[merged_df["__time__"] < cutoff].copy()
    test_df = merged_df[merged_df["__time__"] >= cutoff].copy()

    if train_df.empty or test_df.empty:
        raise ValueError("Temporal split produced empty train or test set.")

    train_df["y"] = ensure_binary_label(train_df["label"])
    test_df["y"] = ensure_binary_label(test_df["label"])

    rows = []
    for fs_name, cols in feature_sets.items():
        X_train = train_df[cols].fillna(0)
        X_test = test_df[cols].fillna(0)
        y_train = train_df["y"]
        y_test = test_df["y"]

        for model_name, model in get_models(random_state=random_state).items():
            model.fit(X_train, y_train)
            y_pred = model.predict(X_test)
            metrics = compute_metrics(y_test, y_pred)

            rows.append({
                "Feature Set": fs_name,
                "Model": model_name,
                "#Features": len(cols),
                "Time Column": time_col,
                "Merge Keys": "|".join(merge_keys),
                "Cutoff": str(cutoff),
                "Train N": int(len(train_df)),
                "Test N": int(len(test_df)),
                "Train Malicious": int((y_train == 1).sum()),
                "Test Malicious": int((y_test == 1).sum()),
                **metrics,
            })

    result = pd.DataFrame(rows)
    order = ["Metadata-only", "Full model", "Behavior-only", "Discordance-only", "Full+Discordance"]
    result["__order"] = result["Feature Set"].map({k: i for i, k in enumerate(order)}).fillna(999)
    result = result.sort_values(["__order", "Model"]).drop(columns="__order").reset_index(drop=True)

    summary = {
        "merge_keys": merge_keys,
        "time_column": time_col,
        "rows_after_merge": int(len(merged_df)),
        "train_rows": int(len(train_df)),
        "test_rows": int(len(test_df)),
        "train_malicious": int((train_df["y"] == 1).sum()),
        "test_malicious": int((test_df["y"] == 1).sum()),
        "cutoff": str(cutoff),
    }
    return result, summary


def cmd_run_temporal(args) -> None:
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    features_df = pd.read_csv(args.features_csv)
    corpus_df = pd.read_csv(args.corpus_csv)
    feature_sets = load_feature_sets(Path(args.feature_groups_json))
    results, summary = run_temporal(
        features_df=features_df,
        corpus_df=corpus_df,
        feature_sets=feature_sets,
        random_state=args.random_state,
    )
    results.to_csv(out_dir / "temporal_results.csv", index=False)
    (out_dir / "temporal_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(results.to_string(index=False))
    print("\nSummary:")
    print(json.dumps(summary, indent=2, ensure_ascii=False))


# ============================================================
# Step 8: Metadata ablation
# ============================================================

def run_group_ablation(df: pd.DataFrame, groups: Dict[str, List[str]], random_state: int, test_size: float) -> pd.DataFrame:
    work = df.copy()
    work["y"] = ensure_binary_label(work["label"])
    train_df, test_df = train_test_split(
        work,
        test_size=test_size,
        random_state=random_state,
        stratify=stratify_labels(work),
    )

    rows = []
    for group_name, cols in groups.items():
        missing = [c for c in cols if c not in work.columns]
        if missing:
            raise ValueError(f"Missing metadata columns for group '{group_name}': {missing}")
        X_train = train_df[cols].fillna(0)
        X_test = test_df[cols].fillna(0)
        y_train = train_df["y"]
        y_test = test_df["y"]

        for model_name, model in get_models(random_state=random_state).items():
            model.fit(X_train, y_train)
            y_pred = model.predict(X_test)
            rows.append({
                "Feature Group": group_name,
                "Model": model_name,
                "#Features": len(cols),
                **compute_metrics(y_test, y_pred),
            })

    result = pd.DataFrame(rows).sort_values(["Feature Group", "Model"]).reset_index(drop=True)
    return result


def cmd_run_metadata_ablation(args) -> None:
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    df = pd.read_csv(args.features_csv)
    groups = build_metadata_groups(df)
    results = run_group_ablation(df, groups, args.random_state, args.test_size)
    results.to_csv(out_dir / "metadata_group_ablation.csv", index=False)
    (out_dir / "metadata_group_manifest.json").write_text(
        json.dumps(groups, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    (out_dir / "metadata_group_summary.json").write_text(
        json.dumps({"group_sizes": {k: len(v) for k, v in groups.items()}}, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    print(results.to_string(index=False))


# ============================================================
# Step 9: Ranking / triage
# ============================================================

def get_score(model, X: pd.DataFrame) -> np.ndarray:
    if hasattr(model, "predict_proba"):
        proba = model.predict_proba(X)
        if proba.ndim == 2 and proba.shape[1] >= 2:
            return proba[:, 1]
        return np.asarray(proba).ravel()
    if hasattr(model, "decision_function"):
        return np.asarray(model.decision_function(X)).ravel()
    return np.asarray(model.predict(X)).astype(float).ravel()


def precision_at_k(y_true_sorted: np.ndarray, k: int) -> float:
    k = min(k, len(y_true_sorted))
    if k == 0:
        return 0.0
    return float(np.mean(y_true_sorted[:k]))


def recall_at_k(y_true_sorted: np.ndarray, k: int) -> float:
    total_pos = int(np.sum(y_true_sorted))
    if total_pos == 0:
        return 0.0
    k = min(k, len(y_true_sorted))
    return float(np.sum(y_true_sorted[:k]) / total_pos)


def evaluate_ranking(y_true: np.ndarray, scores: np.ndarray, ks: List[int]) -> Tuple[Dict[str, float], np.ndarray]:
    order = np.argsort(-scores)
    y_sorted = y_true[order]
    metrics = {"AP": float(average_precision_score(y_true, scores))}
    for k in ks:
        metrics[f"P@{k}"] = precision_at_k(y_sorted, k)
        metrics[f"R@{k}"] = recall_at_k(y_sorted, k)
    return metrics, order


def build_ranked_output(df_test: pd.DataFrame, scores: np.ndarray, y_true: np.ndarray, order: np.ndarray) -> pd.DataFrame:
    ranked = df_test.copy().reset_index(drop=True)
    ranked["score"] = scores
    ranked["y_true"] = y_true
    ranked = ranked.iloc[order].reset_index(drop=True)
    ranked["rank"] = np.arange(1, len(ranked) + 1)
    preferred_cols = ["rank", "package_name", "ecosystem", "label", "y_true", "score"]
    cols = [c for c in preferred_cols if c in ranked.columns] + [c for c in ranked.columns if c not in preferred_cols]
    return ranked[cols]


def cmd_run_ranking(args) -> None:
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    rankings_dir = out_dir / "rankings"
    rankings_dir.mkdir(parents=True, exist_ok=True)

    df = pd.read_csv(args.features_csv)
    feature_sets = load_feature_sets(Path(args.feature_groups_json))

    work = df.copy()
    work["y"] = ensure_binary_label(work["label"])
    train_df, test_df = train_test_split(
        work,
        test_size=args.test_size,
        random_state=args.random_state,
        stratify=stratify_labels(work),
    )

    rows = []
    manifest = {}
    for fs_name, cols in feature_sets.items():
        X_train = train_df[cols].fillna(0)
        X_test = test_df[cols].fillna(0)
        y_train = train_df["y"].to_numpy()
        y_test = test_df["y"].to_numpy()

        for model_name, model in get_models(random_state=args.random_state).items():
            model.fit(X_train, y_train)
            scores = get_score(model, X_test)
            metrics, order = evaluate_ranking(y_test, scores, args.topk)

            row = {
                "Feature Set": fs_name,
                "Model": model_name,
                "#Features": len(cols),
                "Test N": int(len(test_df)),
                "Test Malicious": int(np.sum(y_test)),
                **metrics,
            }
            rows.append(row)

            safe_name = f"{fs_name.replace(' ', '_')}__{model_name.replace(' ', '_')}.csv"
            ranked_out = build_ranked_output(test_df, scores, y_test, order)
            ranked_out.to_csv(rankings_dir / safe_name, index=False)
            manifest[safe_name] = {
                "feature_set": fs_name,
                "model": model_name,
                "topk": args.topk,
            }

    result = pd.DataFrame(rows)
    order = ["Metadata-only", "Full model", "Behavior-only", "Discordance-only", "Full+Discordance"]
    result["__order"] = result["Feature Set"].map({k: i for i, k in enumerate(order)}).fillna(999)
    result = result.sort_values(["__order", "Model"]).drop(columns="__order").reset_index(drop=True)
    result.to_csv(out_dir / "ranking_triage_results.csv", index=False)
    (out_dir / "ranking_triage_manifest.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(result.to_string(index=False))


# ============================================================
# Step 10: Full npm-only workflow
# ============================================================


# ============================================================
# Step 10: Resampled evaluation with confidence intervals
# ============================================================

def predict_positive_scores(model, X: pd.DataFrame) -> np.ndarray:
    if hasattr(model, "predict_proba"):
        proba = model.predict_proba(X)
        if proba.ndim == 2 and proba.shape[1] >= 2:
            return proba[:, 1]
        return np.ravel(proba)
    if hasattr(model, "decision_function"):
        scores = np.ravel(model.decision_function(X))
        return 1.0 / (1.0 + np.exp(-scores))
    preds = np.ravel(model.predict(X)).astype(float)
    return preds


def compute_metrics_extended(y_true: pd.Series, y_pred: np.ndarray, y_score: Optional[np.ndarray] = None) -> Dict[str, float]:
    y_true = np.asarray(y_true).astype(int)
    y_pred = np.asarray(y_pred).astype(int)
    metrics = {
        "Accuracy": float(accuracy_score(y_true, y_pred)),
        "Precision": float(precision_score(y_true, y_pred, zero_division=0)),
        "Recall": float(recall_score(y_true, y_pred, zero_division=0)),
        "F1": float(f1_score(y_true, y_pred, zero_division=0)),
    }
    if y_score is not None:
        y_score = np.asarray(y_score, dtype=float)
        try:
            metrics["AP"] = float(average_precision_score(y_true, y_score))
        except Exception:
            metrics["AP"] = float('nan')
        try:
            if len(np.unique(y_true)) > 1:
                metrics["ROC_AUC"] = float(roc_auc_score(y_true, y_score))
            else:
                metrics["ROC_AUC"] = float('nan')
        except Exception:
            metrics["ROC_AUC"] = float('nan')
        clipped = np.clip(y_score, 1e-8, 1 - 1e-8)
        try:
            metrics["Brier"] = float(brier_score_loss(y_true, clipped))
        except Exception:
            metrics["Brier"] = float('nan')
        try:
            metrics["LogLoss"] = float(log_loss(y_true, clipped, labels=[0, 1]))
        except Exception:
            metrics["LogLoss"] = float('nan')
    return metrics


def percentile_ci(values: Sequence[float], ci: float = 95.0) -> Tuple[float, float]:
    arr = np.asarray([v for v in values if pd.notna(v)], dtype=float)
    if arr.size == 0:
        return float('nan'), float('nan')
    alpha = (100.0 - ci) / 2.0
    return float(np.percentile(arr, alpha)), float(np.percentile(arr, 100.0 - alpha))


def summarize_resampled_results(df: pd.DataFrame, metric_cols: Sequence[str], ci: float = 95.0) -> pd.DataFrame:
    rows = []
    grp_cols = ["Dataset Variant", "Feature Set", "Model", "#Features"]
    for keys, sub in df.groupby(grp_cols, dropna=False):
        row = {c: v for c, v in zip(grp_cols, keys)}
        row["Repeats"] = int(len(sub))
        for metric in metric_cols:
            vals = sub[metric].astype(float).to_numpy()
            row[f"{metric}_Mean"] = float(np.nanmean(vals))
            row[f"{metric}_Std"] = float(np.nanstd(vals, ddof=1)) if len(vals) > 1 else 0.0
            lo, hi = percentile_ci(vals, ci=ci)
            row[f"{metric}_CI_Low"] = lo
            row[f"{metric}_CI_High"] = hi
        rows.append(row)
    out = pd.DataFrame(rows)
    order = ["Metadata-only", "Full model", "Behavior-only", "Discordance-only", "Full+Discordance"]
    out["__order"] = out["Feature Set"].map({k: i for i, k in enumerate(order)}).fillna(999)
    out = out.sort_values(["Dataset Variant", "__order", "Model"]).drop(columns="__order").reset_index(drop=True)
    return out


def sign_flip_permutation_pvalue(deltas: Sequence[float], n_perm: int = 5000, seed: int = 42) -> float:
    arr = np.asarray([d for d in deltas if pd.notna(d)], dtype=float)
    if arr.size == 0:
        return float('nan')
    obs = abs(arr.mean())
    if obs == 0:
        return 1.0
    rng = np.random.default_rng(seed)
    count = 0
    for _ in range(int(n_perm)):
        signs = rng.choice([-1.0, 1.0], size=arr.size)
        stat = abs((arr * signs).mean())
        if stat >= obs:
            count += 1
    return float((count + 1) / (n_perm + 1))


def build_default_comparisons() -> List[Tuple[str, str]]:
    return [
        ("Full model", "Full+Discordance"),
        ("Metadata-only", "Full model"),
        ("Metadata-only", "Discordance-only"),
        ("Behavior-only", "Discordance-only"),
    ]


def build_resampled_records(df: pd.DataFrame, feature_sets: Dict[str, List[str]], repeats: int, base_seed: int, test_size: float,
                            dataset_variant: str) -> pd.DataFrame:
    metric_rows = []
    for rep in range(int(repeats)):
        seed = int(base_seed) + rep
        work = df.copy()
        work["y"] = ensure_binary_label(work["label"])
        train_df, test_df = train_test_split(
            work,
            test_size=test_size,
            random_state=seed,
            stratify=stratify_labels(work),
        )
        y_train = train_df["y"]
        y_test = test_df["y"]
        for fs_name, cols in feature_sets.items():
            X_train = train_df[cols].fillna(0)
            X_test = test_df[cols].fillna(0)
            for model_name, model in get_models(random_state=seed).items():
                est = clone(model)
                est.fit(X_train, y_train)
                y_pred = est.predict(X_test)
                y_score = predict_positive_scores(est, X_test)
                rec = {
                    "Repeat": rep,
                    "Seed": seed,
                    "Dataset Variant": dataset_variant,
                    "Feature Set": fs_name,
                    "Model": model_name,
                    "#Features": len(cols),
                    "Train N": int(len(train_df)),
                    "Test N": int(len(test_df)),
                    "Train Malicious": int((y_train == 1).sum()),
                    "Test Malicious": int((y_test == 1).sum()),
                }
                rec.update(compute_metrics_extended(y_test, y_pred, y_score))
                metric_rows.append(rec)
    return pd.DataFrame(metric_rows)


def paired_comparison_from_resamples(df: pd.DataFrame, metric: str, comparisons: Sequence[Tuple[str, str]],
                                     n_perm: int = 5000, seed: int = 42) -> pd.DataFrame:
    rows = []
    group_cols = ["Dataset Variant", "Model"]
    for (dataset_variant, model_name), sub in df.groupby(group_cols, dropna=False):
        pivot = sub.pivot_table(index="Repeat", columns="Feature Set", values=metric, aggfunc="first")
        for left, right in comparisons:
            if left not in pivot.columns or right not in pivot.columns:
                continue
            deltas = (pivot[right] - pivot[left]).dropna()
            if deltas.empty:
                continue
            ci_lo, ci_hi = percentile_ci(deltas.values, ci=95.0)
            rows.append({
                "Dataset Variant": dataset_variant,
                "Model": model_name,
                "Metric": metric,
                "Left": left,
                "Right": right,
                "Repeats": int(len(deltas)),
                "Mean_Delta_RightMinusLeft": float(deltas.mean()),
                "Median_Delta_RightMinusLeft": float(deltas.median()),
                "CI_Low": ci_lo,
                "CI_High": ci_hi,
                "Permutation_pvalue": sign_flip_permutation_pvalue(deltas.values, n_perm=n_perm, seed=seed),
            })
    return pd.DataFrame(rows)


def cmd_run_resampled_eval(args) -> None:
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(args.features_csv)
    groups = json.loads(Path(args.feature_groups_json).read_text(encoding="utf-8"))
    feature_sets = {
        "Metadata-only": groups["PURE_METADATA_COLS"],
        "Behavior-only": groups["PURE_BEHAVIOR_COLS"],
        "Full model": groups["PURE_FULL_COLS"],
        "Discordance-only": groups["DISCORDANCE_COLS"],
        "Full+Discordance": groups["FULL_WITH_DISCORDANCE_COLS"],
    }
    clean_records = build_resampled_records(df, feature_sets, args.repeats, args.random_state, args.test_size, "Clean")
    matched_records = []
    for rep in range(int(args.repeats)):
        matched = build_matched_availability_subset(df, random_state=int(args.random_state) + rep)
        matched_records.append(build_resampled_records(matched, feature_sets, 1, int(args.random_state) + rep, args.test_size, "Matched"))
    matched_records = pd.concat(matched_records, axis=0).reset_index(drop=True)
    all_records = pd.concat([clean_records, matched_records], axis=0).reset_index(drop=True)
    metric_cols = ["Accuracy", "Precision", "Recall", "F1", "AP", "ROC_AUC", "Brier", "LogLoss"]
    summary = summarize_resampled_results(all_records, metric_cols, ci=args.ci)
    comparisons = build_default_comparisons()
    comp_rows = []
    for metric in ["F1", "AP", "ROC_AUC", "Brier", "LogLoss"]:
        comp_rows.append(paired_comparison_from_resamples(all_records, metric, comparisons, n_perm=args.n_perm, seed=args.random_state))
    comp_df = pd.concat(comp_rows, axis=0).reset_index(drop=True)
    all_records.to_csv(out_dir / "resampled_eval_raw.csv", index=False)
    summary.to_csv(out_dir / "resampled_eval_summary.csv", index=False)
    comp_df.to_csv(out_dir / "resampled_eval_pairwise.csv", index=False)
    manifest = {
        "repeats": int(args.repeats),
        "test_size": float(args.test_size),
        "ci": float(args.ci),
        "n_perm": int(args.n_perm),
        "metric_columns": metric_cols,
    }
    (out_dir / "resampled_eval_manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"[OK] Wrote resampled evaluation outputs to {out_dir}")


# ============================================================
# Step 11: Attack calibration and confidence-shift analysis
# ============================================================

def ece_score(y_true: np.ndarray, y_prob: np.ndarray, n_bins: int = 10) -> float:
    y_true = np.asarray(y_true).astype(int)
    y_prob = np.asarray(y_prob, dtype=float)
    bins = np.linspace(0.0, 1.0, n_bins + 1)
    total = len(y_true)
    ece = 0.0
    for i in range(n_bins):
        left, right = bins[i], bins[i + 1]
        if i == n_bins - 1:
            mask = (y_prob >= left) & (y_prob <= right)
        else:
            mask = (y_prob >= left) & (y_prob < right)
        if not np.any(mask):
            continue
        conf = float(np.mean(y_prob[mask]))
        acc = float(np.mean(y_true[mask]))
        ece += (np.sum(mask) / total) * abs(acc - conf)
    return float(ece)


def compute_calibration_metrics(y_true: np.ndarray, y_prob: np.ndarray, n_bins: int = 10) -> Dict[str, float]:
    y_true = np.asarray(y_true).astype(int)
    y_prob = np.clip(np.asarray(y_prob, dtype=float), 1e-8, 1 - 1e-8)
    y_pred = (y_prob >= 0.5).astype(int)
    out = compute_metrics_extended(y_true, y_pred, y_prob)
    out["ECE"] = ece_score(y_true, y_prob, n_bins=n_bins)
    out["MeanScore_All"] = float(np.mean(y_prob))
    out["MeanScore_Malicious"] = float(np.mean(y_prob[y_true == 1])) if np.any(y_true == 1) else float('nan')
    out["MeanScore_Benign"] = float(np.mean(y_prob[y_true == 0])) if np.any(y_true == 0) else float('nan')
    out["ConfidenceGap_MalMinusBen"] = out["MeanScore_Malicious"] - out["MeanScore_Benign"] if pd.notna(out["MeanScore_Malicious"]) and pd.notna(out["MeanScore_Benign"]) else float('nan')
    return out


def cmd_run_attack_calibration(args) -> None:
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    df_feat = pd.read_csv(args.features_csv)
    groups = json.loads(Path(args.feature_groups_json).read_text(encoding="utf-8"))
    feature_sets = {
        "Metadata-only": groups["PURE_METADATA_COLS"],
        "Behavior-only": groups["PURE_BEHAVIOR_COLS"],
        "Full model": groups["PURE_FULL_COLS"],
        "Discordance-only": groups["DISCORDANCE_COLS"],
        "Full+Discordance": groups["FULL_WITH_DISCORDANCE_COLS"],
    }
    train_df, clean_test_df = get_clean_split(df_feat, args.random_state, args.test_size)
    trained_models = train_clean_models(train_df, feature_sets, args.random_state)

    raw_rows = []
    for attack_name in ATTACK_VARIANTS:
        attacked_source = apply_attack(clean_test_df, attack_name)
        attacked_feat = rebuild_features_from_source(attacked_source)
        attacked_feat["y"] = ensure_binary_label(attacked_feat["label"])
        y_true = attacked_feat["y"].to_numpy()
        for fs_name, cols in feature_sets.items():
            X_test = attacked_feat[cols].fillna(0)
            for model_name in ["Logistic Regression", "Random Forest"]:
                model = trained_models[(fs_name, model_name)]
                y_prob = predict_positive_scores(model, X_test)
                row = {
                    "Attack": attack_name,
                    "Feature Set": fs_name,
                    "Model": model_name,
                    "#Features": len(cols),
                }
                row.update(compute_calibration_metrics(y_true, y_prob, n_bins=args.n_bins))
                raw_rows.append(row)
    cal_df = pd.DataFrame(raw_rows)
    baseline = cal_df[cal_df["Attack"] == "A0_Clean"].copy()
    shift_rows = []
    merge_cols = ["Feature Set", "Model"]
    metrics_to_shift = ["F1", "AP", "ROC_AUC", "Brier", "LogLoss", "ECE", "MeanScore_Malicious", "ConfidenceGap_MalMinusBen"]
    for attack_name, sub in cal_df.groupby("Attack"):
        if attack_name == "A0_Clean":
            continue
        merged = sub.merge(baseline, on=merge_cols, suffixes=("", "_Clean"))
        for _, r in merged.iterrows():
            row = {"Attack": attack_name, "Feature Set": r["Feature Set"], "Model": r["Model"]}
            for metric in metrics_to_shift:
                row[f"{metric}_Delta_vs_Clean"] = float(r[metric] - r[f"{metric}_Clean"])
            shift_rows.append(row)
    shift_df = pd.DataFrame(shift_rows)
    cal_df.to_csv(out_dir / "attack_calibration_results.csv", index=False)
    shift_df.to_csv(out_dir / "attack_calibration_shifts.csv", index=False)
    (out_dir / "attack_calibration_manifest.json").write_text(
        json.dumps({"n_bins": int(args.n_bins), "test_size": float(args.test_size)}, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    print(f"[OK] Wrote attack calibration outputs to {out_dir}")


# ============================================================
# Step 12: Stratified stability within npm
# ============================================================

def add_stratification_columns(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["metadata_richness_bin"] = pd.cut(out["metadata_presence_score"].fillna(0), bins=[-1, 2, 5, 9, 20], labels=["low", "medium", "high", "very_high"], include_lowest=True).astype(str)
    out["doc_richness_bin"] = pd.cut(out["readme_len"].fillna(0), bins=[-1, 0, 100, 1000, 1000000000], labels=["none", "short", "medium", "long"], include_lowest=True).astype(str)
    out["behavior_richness_bin"] = pd.cut(out["behavior_len"].fillna(0), bins=[-1, 100, 1000, 10000, 1000000000], labels=["low", "medium", "high", "very_high"], include_lowest=True).astype(str)
    return out


def add_age_bins(features_df: pd.DataFrame, corpus_df: pd.DataFrame) -> pd.DataFrame:
    merged, _, _ = merge_features_with_corpus(features_df, corpus_df)
    max_time = merged["__time__"].max()
    age_days = (max_time - merged["__time__"]).dt.days.astype(float)
    merged["age_days"] = age_days
    merged["age_bin"] = pd.cut(age_days, bins=[-1, 30, 180, 365, 10000], labels=["new", "recent", "mature", "old"], include_lowest=True).astype(str)
    return merged


def evaluate_subset_with_trained_models(sub_df: pd.DataFrame, feature_sets: Dict[str, List[str]], trained_models: Dict[Tuple[str, str], object],
                                        attack_name: str, stratum_name: str, stratum_value: str) -> pd.DataFrame:
    sub = sub_df.copy()
    sub["y"] = ensure_binary_label(sub["label"])
    y_true = sub["y"].to_numpy()
    rows = []
    for fs_name, cols in feature_sets.items():
        X_test = sub[cols].fillna(0)
        for model_name in ["Logistic Regression", "Random Forest"]:
            model = trained_models[(fs_name, model_name)]
            y_pred = model.predict(X_test)
            y_score = predict_positive_scores(model, X_test)
            row = {
                "Attack": attack_name,
                "Stratum": stratum_name,
                "Stratum Value": stratum_value,
                "Feature Set": fs_name,
                "Model": model_name,
                "N": int(len(sub)),
                "Malicious": int(np.sum(y_true == 1)),
                "Benign": int(np.sum(y_true == 0)),
            }
            row.update(compute_metrics_extended(y_true, y_pred, y_score))
            rows.append(row)
    return pd.DataFrame(rows)


def cmd_run_stratified_stability(args) -> None:
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    features_df = pd.read_csv(args.features_csv)
    corpus_df = pd.read_csv(args.corpus_csv)
    groups = json.loads(Path(args.feature_groups_json).read_text(encoding="utf-8"))
    feature_sets = {
        "Metadata-only": groups["PURE_METADATA_COLS"],
        "Behavior-only": groups["PURE_BEHAVIOR_COLS"],
        "Full model": groups["PURE_FULL_COLS"],
        "Discordance-only": groups["DISCORDANCE_COLS"],
        "Full+Discordance": groups["FULL_WITH_DISCORDANCE_COLS"],
    }
    features_aug = add_age_bins(features_df, corpus_df)
    features_aug = add_stratification_columns(features_aug)
    train_df, clean_test_df = get_clean_split(features_aug, args.random_state, args.test_size)
    trained_models = train_clean_models(train_df, feature_sets, args.random_state)

    clean_eval = add_stratification_columns(clean_test_df)
    attack_eval = add_stratification_columns(rebuild_features_from_source(apply_attack(clean_test_df, args.attack_name)))
    # Preserve derived age bins from clean split by joining on stable keys where possible.
    join_cols = [c for c in ["package_name", "ecosystem", "label"] if c in clean_eval.columns and c in attack_eval.columns]
    extra_cols = [c for c in ["age_bin", "metadata_richness_bin", "doc_richness_bin", "behavior_richness_bin", "inferred_role"] if c in clean_eval.columns]
    if join_cols:
        attack_eval = attack_eval.drop(columns=[c for c in extra_cols if c in attack_eval.columns], errors="ignore").merge(clean_eval[join_cols + extra_cols].drop_duplicates(), on=join_cols, how="left")

    strata_specs = [
        "inferred_role",
        "metadata_richness_bin",
        "doc_richness_bin",
        "behavior_richness_bin",
        "age_bin",
    ]
    rows = []
    for attack_name, frame in [("A0_Clean", clean_eval), (args.attack_name, attack_eval)]:
        for strat in strata_specs:
            if strat not in frame.columns:
                continue
            for value, sub in frame.groupby(strat, dropna=False):
                if len(sub) < args.min_samples or sub["label"].nunique() < 2:
                    continue
                rows.append(evaluate_subset_with_trained_models(sub, feature_sets, trained_models, attack_name, strat, safe_text(value)))
    results = pd.concat(rows, axis=0).reset_index(drop=True) if rows else pd.DataFrame()
    shifts = []
    if not results.empty:
        baseline = results[results["Attack"] == "A0_Clean"]
        attacked = results[results["Attack"] == args.attack_name]
        merge_cols = ["Stratum", "Stratum Value", "Feature Set", "Model"]
        merged = attacked.merge(baseline, on=merge_cols, suffixes=("", "_Clean"))
        for _, r in merged.iterrows():
            shifts.append({
                "Attack": args.attack_name,
                "Stratum": r["Stratum"],
                "Stratum Value": r["Stratum Value"],
                "Feature Set": r["Feature Set"],
                "Model": r["Model"],
                "N_Attack": int(r["N"]),
                "N_Clean": int(r["N_Clean"]),
                "F1_Delta": float(r["F1"] - r["F1_Clean"]),
                "AP_Delta": float(r["AP"] - r["AP_Clean"]),
                "ROC_AUC_Delta": float(r["ROC_AUC"] - r["ROC_AUC_Clean"]),
            })
    shifts_df = pd.DataFrame(shifts)
    results.to_csv(out_dir / "stratified_stability_results.csv", index=False)
    shifts_df.to_csv(out_dir / "stratified_stability_shifts.csv", index=False)
    (out_dir / "stratified_stability_manifest.json").write_text(
        json.dumps({"attack_name": args.attack_name, "min_samples": int(args.min_samples), "test_size": float(args.test_size)}, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    print(f"[OK] Wrote stratified stability outputs to {out_dir}")


# ============================================================
# Full enhanced pipeline
# ============================================================

def cmd_full_npm(args) -> None:
    base = Path(args.base_dir)
    base.mkdir(parents=True, exist_ok=True)

    manifests_dir = base / "manifests"
    manifests_npm_dir = base / "manifests_npm"
    data_dir = base / "data_npm_live"
    features_dir = base / "features_npm_live"
    clean_dir = base / "experiments_npm_clean_matched"
    attacks_dir = base / "experiments_npm_attacks"
    temporal_dir = base / "temporal_eval"
    ablation_dir = base / "metadata_ablation"
    ranking_dir = base / "ranking_triage_eval"
    resampled_dir = base / "resampled_eval"
    attack_calib_dir = base / "attack_calibration"
    stratified_dir = base / "stratified_stability"

    cmd_build_malicious_manifest(argparse.Namespace(
        out_dir=str(manifests_dir),
        work_dir=args.work_dir,
        datadog_repo=args.datadog_repo,
        ossf_repo=args.ossf_repo,
        clone_if_missing=args.clone_if_missing,
        target=args.malicious_target,
        random_state=args.random_state,
    ))

    cmd_build_benign_manifest(argparse.Namespace(
        out_dir=str(manifests_npm_dir),
        target=args.benign_target,
        random_state=args.random_state,
        pages_per_term=args.pages_per_term,
        page_size=args.page_size,
        sleep_seconds=args.sleep_seconds,
        timeout=args.timeout,
    ))

    mal_src = manifests_dir / "malicious_packages_npm.csv"
    mal_dst = manifests_npm_dir / "malicious_packages_npm.csv"
    pd.read_csv(mal_src).to_csv(mal_dst, index=False)

    cmd_build_corpus_live(argparse.Namespace(
        malicious_manifest=str(mal_dst),
        benign_manifest=str(manifests_npm_dir / "benign_packages_npm.csv"),
        out_dir=str(data_dir),
        max_malicious=args.malicious_target,
        max_benign=args.benign_target,
        random_state=args.random_state,
        skip_tarball_scan=args.skip_tarball_scan,
        tarball_max_files=args.tarball_max_files,
        tarball_max_bytes=args.tarball_max_bytes,
        sleep_seconds=args.sleep_seconds,
        timeout=args.timeout,
    ))

    cmd_build_features(argparse.Namespace(
        input_corpus=str(data_dir / "normalized_corpus_live.csv"),
        out_dir=str(features_dir),
    ))

    cmd_run_clean_matched(argparse.Namespace(
        features_csv=str(features_dir / "features.csv"),
        feature_groups_json=str(features_dir / "feature_groups.json"),
        out_dir=str(clean_dir),
        random_state=args.random_state,
        test_size=args.test_size,
    ))

    cmd_run_attacks(argparse.Namespace(
        features_csv=str(features_dir / "features.csv"),
        feature_groups_json=str(features_dir / "feature_groups.json"),
        out_dir=str(attacks_dir),
        random_state=args.random_state,
        test_size=args.test_size,
    ))

    cmd_run_temporal(argparse.Namespace(
        features_csv=str(features_dir / "features.csv"),
        feature_groups_json=str(features_dir / "feature_groups.json"),
        corpus_csv=str(data_dir / "normalized_corpus_live.csv"),
        out_dir=str(temporal_dir),
        random_state=args.random_state,
    ))

    cmd_run_metadata_ablation(argparse.Namespace(
        features_csv=str(features_dir / "features.csv"),
        out_dir=str(ablation_dir),
        random_state=args.random_state,
        test_size=args.test_size,
    ))

    cmd_run_ranking(argparse.Namespace(
        features_csv=str(features_dir / "features.csv"),
        feature_groups_json=str(features_dir / "feature_groups.json"),
        out_dir=str(ranking_dir),
        random_state=args.random_state,
        test_size=args.test_size,
        topk=args.topk,
    ))

    cmd_run_resampled_eval(argparse.Namespace(
        features_csv=str(features_dir / "features.csv"),
        feature_groups_json=str(features_dir / "feature_groups.json"),
        out_dir=str(resampled_dir),
        random_state=args.random_state,
        repeats=args.repeats,
        test_size=args.test_size,
        ci=args.ci,
        n_perm=args.n_perm,
    ))

    cmd_run_attack_calibration(argparse.Namespace(
        features_csv=str(features_dir / "features.csv"),
        feature_groups_json=str(features_dir / "feature_groups.json"),
        out_dir=str(attack_calib_dir),
        random_state=args.random_state,
        test_size=args.test_size,
        n_bins=args.n_bins,
    ))

    cmd_run_stratified_stability(argparse.Namespace(
        features_csv=str(features_dir / "features.csv"),
        feature_groups_json=str(features_dir / "feature_groups.json"),
        corpus_csv=str(data_dir / "normalized_corpus_live.csv"),
        out_dir=str(stratified_dir),
        random_state=args.random_state,
        test_size=args.test_size,
        attack_name=args.stratified_attack_name,
        min_samples=args.min_samples,
    ))

    artifact_manifest = {
        "base_dir": str(base),
        "malicious_manifest": str(mal_dst),
        "benign_manifest": str(manifests_npm_dir / "benign_packages_npm.csv"),
        "corpus_csv": str(data_dir / "normalized_corpus_live.csv"),
        "features_csv": str(features_dir / "features.csv"),
        "feature_groups_json": str(features_dir / "feature_groups.json"),
        "clean_results_csv": str(clean_dir / "clean_results.csv"),
        "matched_results_csv": str(clean_dir / "matched_results.csv"),
        "attack_results_csv": str(attacks_dir / "attack_results.csv"),
        "temporal_results_csv": str(temporal_dir / "temporal_results.csv"),
        "metadata_ablation_csv": str(ablation_dir / "metadata_group_ablation.csv"),
        "ranking_results_csv": str(ranking_dir / "ranking_triage_results.csv"),
        "resampled_summary_csv": str(resampled_dir / "resampled_eval_summary.csv"),
        "resampled_pairwise_csv": str(resampled_dir / "resampled_eval_pairwise.csv"),
        "attack_calibration_csv": str(attack_calib_dir / "attack_calibration_results.csv"),
        "attack_calibration_shifts_csv": str(attack_calib_dir / "attack_calibration_shifts.csv"),
        "stratified_stability_csv": str(stratified_dir / "stratified_stability_results.csv"),
        "stratified_stability_shifts_csv": str(stratified_dir / "stratified_stability_shifts.csv"),
    }
    (manifests_dir / "artifact_manifest.json").write_text(
        json.dumps(artifact_manifest, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(f"[OK] Full enhanced npm-only pipeline completed in {base}")


# ============================================================
# CLI
# ============================================================

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Enhanced npm-only IBD paper pipeline")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("build_malicious_manifest")
    p.add_argument("--out-dir", required=True)
    p.add_argument("--work-dir", default="./external_sources")
    p.add_argument("--datadog-repo", default=None)
    p.add_argument("--ossf-repo", default=None)
    p.add_argument("--clone-if-missing", action="store_true")
    p.add_argument("--target", type=int, default=None)
    p.add_argument("--random-state", type=int, default=42)
    p.set_defaults(func=cmd_build_malicious_manifest)

    p = sub.add_parser("build_benign_manifest")
    p.add_argument("--out-dir", required=True)
    p.add_argument("--target", type=int, default=2500)
    p.add_argument("--random-state", type=int, default=42)
    p.add_argument("--pages-per-term", type=int, default=5)
    p.add_argument("--page-size", type=int, default=100)
    p.add_argument("--sleep-seconds", type=float, default=0.1)
    p.add_argument("--timeout", type=int, default=20)
    p.set_defaults(func=cmd_build_benign_manifest)

    p = sub.add_parser("build_corpus_live")
    p.add_argument("--malicious-manifest", required=True)
    p.add_argument("--benign-manifest", required=True)
    p.add_argument("--out-dir", required=True)
    p.add_argument("--max-malicious", type=int, default=2500)
    p.add_argument("--max-benign", type=int, default=2500)
    p.add_argument("--random-state", type=int, default=42)
    p.add_argument("--skip-tarball-scan", action="store_true")
    p.add_argument("--tarball-max-files", type=int, default=250)
    p.add_argument("--tarball-max-bytes", type=int, default=2500000)
    p.add_argument("--sleep-seconds", type=float, default=0.1)
    p.add_argument("--timeout", type=int, default=20)
    p.set_defaults(func=cmd_build_corpus_live)

    p = sub.add_parser("build_features")
    p.add_argument("--input-corpus", required=True)
    p.add_argument("--out-dir", required=True)
    p.set_defaults(func=cmd_build_features)

    p = sub.add_parser("run_clean_matched")
    p.add_argument("--features-csv", required=True)
    p.add_argument("--feature-groups-json", required=True)
    p.add_argument("--out-dir", required=True)
    p.add_argument("--random-state", type=int, default=42)
    p.add_argument("--test-size", type=float, default=0.25)
    p.set_defaults(func=cmd_run_clean_matched)

    p = sub.add_parser("run_attacks")
    p.add_argument("--features-csv", required=True)
    p.add_argument("--feature-groups-json", required=True)
    p.add_argument("--out-dir", required=True)
    p.add_argument("--random-state", type=int, default=42)
    p.add_argument("--test-size", type=float, default=0.25)
    p.set_defaults(func=cmd_run_attacks)

    p = sub.add_parser("run_temporal")
    p.add_argument("--features-csv", required=True)
    p.add_argument("--feature-groups-json", required=True)
    p.add_argument("--corpus-csv", required=True)
    p.add_argument("--out-dir", required=True)
    p.add_argument("--random-state", type=int, default=42)
    p.set_defaults(func=cmd_run_temporal)

    p = sub.add_parser("run_metadata_ablation")
    p.add_argument("--features-csv", required=True)
    p.add_argument("--out-dir", required=True)
    p.add_argument("--random-state", type=int, default=42)
    p.add_argument("--test-size", type=float, default=0.25)
    p.set_defaults(func=cmd_run_metadata_ablation)

    p = sub.add_parser("run_ranking")
    p.add_argument("--features-csv", required=True)
    p.add_argument("--feature-groups-json", required=True)
    p.add_argument("--out-dir", required=True)
    p.add_argument("--random-state", type=int, default=42)
    p.add_argument("--test-size", type=float, default=0.25)
    p.add_argument("--topk", nargs="*", type=int, default=[10, 20, 50])
    p.set_defaults(func=cmd_run_ranking)

    p = sub.add_parser("run_resampled_eval")
    p.add_argument("--features-csv", required=True)
    p.add_argument("--feature-groups-json", required=True)
    p.add_argument("--out-dir", required=True)
    p.add_argument("--random-state", type=int, default=42)
    p.add_argument("--repeats", type=int, default=30)
    p.add_argument("--test-size", type=float, default=0.25)
    p.add_argument("--ci", type=float, default=95.0)
    p.add_argument("--n-perm", type=int, default=5000)
    p.set_defaults(func=cmd_run_resampled_eval)

    p = sub.add_parser("run_attack_calibration")
    p.add_argument("--features-csv", required=True)
    p.add_argument("--feature-groups-json", required=True)
    p.add_argument("--out-dir", required=True)
    p.add_argument("--random-state", type=int, default=42)
    p.add_argument("--test-size", type=float, default=0.25)
    p.add_argument("--n-bins", type=int, default=10)
    p.set_defaults(func=cmd_run_attack_calibration)

    p = sub.add_parser("run_stratified_stability")
    p.add_argument("--features-csv", required=True)
    p.add_argument("--feature-groups-json", required=True)
    p.add_argument("--corpus-csv", required=True)
    p.add_argument("--out-dir", required=True)
    p.add_argument("--random-state", type=int, default=42)
    p.add_argument("--test-size", type=float, default=0.25)
    p.add_argument("--attack-name", default="A4_SelectiveDeception")
    p.add_argument("--min-samples", type=int, default=30)
    p.set_defaults(func=cmd_run_stratified_stability)

    p = sub.add_parser("full_npm")
    p.add_argument("--base-dir", required=True)
    p.add_argument("--work-dir", default="./external_sources")
    p.add_argument("--datadog-repo", default=None)
    p.add_argument("--ossf-repo", default=None)
    p.add_argument("--clone-if-missing", action="store_true")
    p.add_argument("--random-state", type=int, default=42)
    p.add_argument("--sleep-seconds", type=float, default=0.1)
    p.add_argument("--timeout", type=int, default=20)
    p.add_argument("--test-size", type=float, default=0.25)
    p.add_argument("--malicious-target", type=int, default=2500)
    p.add_argument("--benign-target", type=int, default=2500)
    p.add_argument("--pages-per-term", type=int, default=5)
    p.add_argument("--page-size", type=int, default=100)
    p.add_argument("--skip-tarball-scan", action="store_true")
    p.add_argument("--tarball-max-files", type=int, default=250)
    p.add_argument("--tarball-max-bytes", type=int, default=2500000)
    p.add_argument("--topk", nargs="*", type=int, default=[10, 20, 50])
    p.add_argument("--repeats", type=int, default=30)
    p.add_argument("--ci", type=float, default=95.0)
    p.add_argument("--n-perm", type=int, default=5000)
    p.add_argument("--n-bins", type=int, default=10)
    p.add_argument("--stratified-attack-name", default="A4_SelectiveDeception")
    p.add_argument("--min-samples", type=int, default=30)
    p.set_defaults(func=cmd_full_npm)

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
